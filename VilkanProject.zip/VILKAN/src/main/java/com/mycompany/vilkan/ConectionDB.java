/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vilkan;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author ivan2
 */
public class ConectionDB {

    public ConectionDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }
    PasswordAuthentication pass = new PasswordAuthentication();

    public boolean selecionar(String nome, String passe) {
        boolean a = false;
        try {
        Connection c;
        c = java.sql.DriverManager.getConnection("jdbc:mysql://localhost/db_vilkran?user=root&password=123456");
        Statement s = c.createStatement(); 
        ResultSet rs = s.executeQuery("SELECT * FROM AUT where usuario = '"+nome+"'");
        while (rs.next()) {
                System.out.println(rs.getString(2));
                a = pass.authenticate(passe.toCharArray(), rs.getString(2));
                if(a){
                    System.out.println("sucesso da clube");
                }else{
                    System.out.println("sexo sem para");
                }
        }
        // FIM SELECT
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return a;
        
    }
    public void novoUsuario(String nome, String senha){
    try {
        Connection c;
        c = java.sql.DriverManager.getConnection("jdbc:mysql://localhost/db_vilkran?user=root&password=admin");
        Statement s = c.createStatement();
        senha = pass.hash(senha.toCharArray());
        System.out.println(senha);
        s.execute("INSERT INTO aut VALUES ('"+nome+"','"+senha+"')");
        // FIM SELECT
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void deletarReg(int id){
        
    try {
        Connection c;
        c = java.sql.DriverManager.getConnection("jdbc:mysql://localhost/teste?user=root&password=123456");
        Statement s = c.createStatement();
        s.execute("DELETE FROM aut WHERE id = " + id);
        // FIM SELECT
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
}
