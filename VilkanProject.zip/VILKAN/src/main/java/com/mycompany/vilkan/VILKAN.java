/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vilkan;

import Interfaces.Tela_Principal;

/**
 *
 * @author ivan.grodrigues
 */
public class VILKAN {

    public static void main(String[] args) {
        Tela_Principal t = new Tela_Principal();
        t.setVisible(true);
    }
}
